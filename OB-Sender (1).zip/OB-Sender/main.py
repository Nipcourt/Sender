import csv
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.header import Header
from string import Template
import time
import json

file = open("smtp.json")

data = json.load(file)

email_sender= data["email"]
password= data["password"]

file = open("subject.json")

data = json.load(file)

subject= data["subject"]

with open('email.csv','r') as csvfile:
    reader=csv.reader(csvfile)
    for line in reader:
        email_html = open('lett.html')
        email_body = email_html.read()
        #You can change the delay time here
        time.sleep(1)
        email_send = line[0]
        msg = MIMEMultipart()
        msg['From'] = str(Header(f'EWE NET <{email_sender}>'))
        msg['To'] = email_send
        msg['Subject'] = subject
        msg.attach(MIMEText(email_body, 'html'))
        text = msg.as_string()

        server=smtplib.SMTP_SSL("smtp.gmx.net",465)
        server.login(email_sender,password)
        server.sendmail(email_sender,email_send,text)


        server.quit()
        print("Mail sent successfully to",email_send)
